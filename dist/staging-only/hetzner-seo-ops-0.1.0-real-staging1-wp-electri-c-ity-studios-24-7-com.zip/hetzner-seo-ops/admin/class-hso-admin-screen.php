<?php

if (!defined('ABSPATH')) {
    exit;
}

class HSO_Admin_Screen
{
    private array $runtime_context;
    private array $bridge_profile;
    private array $license_state;
    private array $connection_state;
    private array $conflict_state;
    private array $baseline_snapshot;
    private array $optimization_state;
    private array $validation_snapshot;

    public function __construct(
        array $runtime_context,
        array $bridge_profile,
        array $license_state,
        array $connection_state,
        array $conflict_state,
        array $baseline_snapshot,
        array $optimization_state,
        array $validation_snapshot
    ) {
        $this->runtime_context = $runtime_context;
        $this->bridge_profile = $bridge_profile;
        $this->license_state = $license_state;
        $this->connection_state = $connection_state;
        $this->conflict_state = $conflict_state;
        $this->baseline_snapshot = $baseline_snapshot;
        $this->optimization_state = $optimization_state;
        $this->validation_snapshot = $validation_snapshot;
    }

    public function register(): void
    {
        add_action('admin_menu', array($this, 'add_menu'));
    }

    public function add_menu(): void
    {
        add_menu_page(
            'Site Optimizer',
            'Site Optimizer',
            'manage_options',
            'hetzner-seo-ops',
            array($this, 'render'),
            'dashicons-admin-tools',
            58
        );
    }

    public function render(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        echo '<div class="wrap">';
        echo '<h1>Site Optimizer Bridge</h1>';
        echo '<p>Doctrine-enforced staging bridge. The plugin stays in observe_only or safe_mode until domain binding, baseline, conflict picture, validation, and rollback gates are satisfied.</p>';
        echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin:16px 0;">';
        $this->render_card('Runtime', $this->runtime_context);
        $this->render_card('Bridge Profile', $this->bridge_profile);
        $this->render_card('License Status', $this->license_state);
        $this->render_card('Suite Connection', $this->connection_state);
        $this->render_card('Conflict Snapshot', $this->conflict_state);
        $this->render_card('Baseline Snapshot', $this->baseline_snapshot);
        $this->render_card('Optimization Readiness', $this->optimization_state);
        $this->render_card('Validation Snapshot', $this->validation_snapshot);
        echo '</div>';
        echo '</div>';
    }

    private function render_card(string $title, array $payload): void
    {
        echo '<section style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px;">';
        echo '<h2 style="margin-top:0;">' . esc_html($title) . '</h2>';
        echo '<pre style="white-space:pre-wrap;word-break:break-word;margin:0;">' . esc_html(wp_json_encode($payload, JSON_PRETTY_PRINT)) . '</pre>';
        echo '</section>';
    }
}
