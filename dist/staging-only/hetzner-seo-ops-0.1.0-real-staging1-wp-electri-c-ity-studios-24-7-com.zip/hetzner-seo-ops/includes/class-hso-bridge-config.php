<?php

if (!defined('ABSPATH')) {
    exit;
}

class HSO_Bridge_Config
{
    private array $config = array();

    public function load(): array
    {
        if (!empty($this->config)) {
            return $this->config;
        }

        $config = $this->default_config();
        $path = HSO_PLUGIN_DIR . 'config/bridge-config.json';
        if (file_exists($path)) {
            $raw = file_get_contents($path);
            if ($raw !== false) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $config = array_merge($config, $decoded);
                }
            }
        }

        $config['allowed_scopes'] = array_values(array_filter(array_map('strval', (array) ($config['allowed_scopes'] ?? array()))));
        $config['required_features'] = array_values(array_filter(array_map('strval', (array) ($config['required_features'] ?? array()))));
        $config['current_blockers'] = array_values(array_filter(array_map('strval', (array) ($config['current_blockers'] ?? array()))));
        $config['stop_conditions'] = array_values(array_filter(array_map('strval', (array) ($config['stop_conditions'] ?? array()))));
        $config['allowed_subdomains'] = array_values(array_filter(array_map(array($this, 'normalize_domain'), (array) ($config['allowed_subdomains'] ?? array()))));
        $config['bound_domain'] = $this->normalize_domain((string) ($config['bound_domain'] ?? ''));

        $this->config = $config;
        return $this->config;
    }

    public function build_license_seed(): array
    {
        $config = $this->load();

        return array(
            'license_id' => (string) ($config['license_id'] ?? 'TBD'),
            'status' => (string) ($config['status'] ?? 'approval_required'),
            'bound_domain' => (string) ($config['bound_domain'] ?? ''),
            'allowed_subdomains' => (array) ($config['allowed_subdomains'] ?? array()),
            'allowed_scopes' => (array) ($config['allowed_scopes'] ?? array()),
            'release_channel' => (string) ($config['release_channel'] ?? 'pilot'),
            'policy_channel' => (string) ($config['policy_channel'] ?? 'pilot'),
            'rollback_profile_id' => (string) ($config['rollback_profile_id'] ?? 'TBD'),
            'operator_inputs_complete' => !empty($config['operator_inputs_complete']),
        );
    }

    public function build_connection_state(string $current_domain): array
    {
        $config = $this->load();
        $bound_domain = $this->normalize_domain((string) ($config['bound_domain'] ?? ''));
        $current_domain = $this->normalize_domain($current_domain);

        return array(
            'connection_mode' => (string) ($config['suite_connection_mode'] ?? 'packaged_preview_only'),
            'readiness' => (string) ($config['suite_connection_readiness'] ?? 'packaged_preview_ready'),
            'bound_domain' => $bound_domain,
            'current_domain' => $current_domain,
            'domain_match' => $bound_domain !== '' && $current_domain === $bound_domain,
            'expected_home_url' => (string) ($config['expected_home_url'] ?? ''),
            'expected_scoped_page_url' => (string) ($config['expected_scoped_page_url'] ?? ''),
            'default_mode' => (string) ($config['default_mode'] ?? 'safe_mode'),
            'fallback_mode' => (string) ($config['fallback_mode'] ?? 'observe_only'),
            'current_blockers' => (array) ($config['current_blockers'] ?? array()),
            'staging_only' => !empty($config['staging_only']),
        );
    }

    public function persist_packaged_profile(): void
    {
        if (!function_exists('update_option')) {
            return;
        }

        update_option('hso_bridge_profile_snapshot', $this->load(), false);
    }

    private function default_config(): array
    {
        return array(
            'schema_version' => 1,
            'bridge_profile' => 'source not yet confirmed',
            'bridge_label' => 'Site Optimizer Bridge',
            'staging_only' => true,
            'suite_connection_mode' => 'packaged_preview_only',
            'suite_connection_readiness' => 'packaged_preview_ready',
            'license_id' => 'TBD',
            'status' => 'approval_required',
            'bound_domain' => '',
            'allowed_subdomains' => array(),
            'path_base' => '/',
            'expected_home_url' => '',
            'expected_scoped_page_url' => '',
            'release_channel' => 'pilot',
            'policy_channel' => 'pilot',
            'rollback_profile_id' => 'TBD',
            'default_mode' => 'safe_mode',
            'fallback_mode' => 'observe_only',
            'allowed_scopes' => array('homepage_only'),
            'required_features' => array('meta_description'),
            'scope_confirmed' => false,
            'source_mapping_confirmed' => false,
            'operator_inputs_complete' => false,
            'optimization_stage' => 'stage1_readiness_only',
            'optimization_readiness' => 'approval_required',
            'current_blockers' => array('operator input required'),
            'stop_conditions' => array('fatal error', 'visible page damage'),
        );
    }

    private function normalize_domain(string $domain): string
    {
        $domain = strtolower(trim($domain));
        $domain = preg_replace('#^https?://#', '', $domain);
        return trim((string) $domain, '/');
    }
}
