<?php

if (!defined('ABSPATH')) {
    exit;
}

class HSO_Optimization_Gate
{
    public function evaluate(
        string $mode,
        array $license_state,
        array $conflict_state,
        array $baseline_snapshot,
        array $bridge_profile
    ): array {
        $allowed = array(
            'baseline_capture',
            'head_diagnostics',
            'structure_diagnostics',
            'visibility_diagnostics',
        );
        $forbidden = array(
            'rank_math_deactivation',
            'sitewide_meta_overwrite',
            'global_head_rewrite',
            'canonical_override',
            'multi_domain_operation',
            'theme_or_builder_replacement',
        );
        $reasons = array();
        $eligibility = 'recommend_only';

        if (empty($license_state['domain_match'])) {
            $eligibility = 'blocked';
            $reasons[] = 'bound domain mismatch';
        }

        if (empty($baseline_snapshot['url_normalization_clean'])) {
            $eligibility = 'blocked';
            $reasons[] = 'url normalization is not yet clean';
        }

        if (!empty($conflict_state['has_blocking_conflict'])) {
            $eligibility = 'blocked';
            $reasons[] = 'blocking plugin conflict is present';
        }

        if (!empty($conflict_state['source_mapping_unclear'])) {
            $reasons[] = 'source mapping remains unclear';
        }

        if (empty($bridge_profile['source_mapping_confirmed'])) {
            $reasons[] = 'source mapping is not confirmed';
        }

        if (empty($bridge_profile['scope_confirmed'])) {
            $reasons[] = 'scope is not confirmed';
        }

        if ($eligibility !== 'blocked' && $mode === 'active_scoped' && empty($conflict_state['source_mapping_unclear']) && !empty($bridge_profile['source_mapping_confirmed']) && !empty($bridge_profile['scope_confirmed'])) {
            $eligibility = 'reversible_change_ready';
            $allowed[] = 'prepare_reversible_homepage_meta_description';
        }

        return array(
            'mode' => $mode,
            'eligibility' => $eligibility,
            'recommendation_only' => $eligibility !== 'reversible_change_ready',
            'allowed_optimizations' => array_values(array_unique($allowed)),
            'forbidden_optimizations' => $forbidden,
            'reasons' => array_values(array_unique($reasons)),
        );
    }
}
