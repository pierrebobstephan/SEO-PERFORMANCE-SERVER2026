<?php

if (!defined('ABSPATH')) {
    exit;
}

class HSO_Plugin
{
    private static ?HSO_Plugin $instance = null;

    private HSO_Bridge_Config $bridge_config;
    private HSO_Baseline_Capture $baseline_capture;
    private HSO_Optimization_Gate $optimization_gate;
    private HSO_License_Check $license_check;
    private HSO_Safe_Mode $safe_mode;
    private HSO_Conflict_Detector $conflict_detector;
    private HSO_Rollback_Registry $rollback_registry;
    private HSO_Validation_Status $validation_status;
    private array $bridge_profile = array();
    private array $connection_state = array();
    private array $baseline_snapshot = array();
    private array $optimization_state = array();
    private array $runtime_context = array();
    private array $license_state = array();
    private array $conflict_state = array();

    public static function activate(): void
    {
        $bridge_config = new HSO_Bridge_Config();
        $bridge_config->persist_packaged_profile();

        if (!function_exists('update_option')) {
            return;
        }

        update_option('hso_local_license_snapshot', $bridge_config->build_license_seed(), false);
        update_option('hso_activation_ready', array(
            'plugin_version' => HSO_PLUGIN_VERSION,
            'bound_domain' => (string) ($bridge_config->load()['bound_domain'] ?? ''),
            'default_mode' => (string) ($bridge_config->load()['default_mode'] ?? 'safe_mode'),
            'activated_at' => gmdate('c'),
        ), false);
    }

    public static function boot(): HSO_Plugin
    {
        if (self::$instance === null) {
            self::$instance = new self();
            self::$instance->register();
        }

        return self::$instance;
    }

    private function __construct()
    {
        $this->bridge_config = new HSO_Bridge_Config();
        $this->license_check = new HSO_License_Check();
        $this->safe_mode = new HSO_Safe_Mode();
        $this->conflict_detector = new HSO_Conflict_Detector();
        $this->rollback_registry = new HSO_Rollback_Registry();
        $this->validation_status = new HSO_Validation_Status();
        $this->optimization_gate = new HSO_Optimization_Gate();
        $this->bridge_profile = $this->bridge_config->load();
        $this->baseline_capture = new HSO_Baseline_Capture($this->bridge_profile);
    }

    private function register(): void
    {
        $current_domain = $this->detect_current_domain();
        $this->license_state = $this->license_check->evaluate_domain($current_domain, $this->bridge_config->build_license_seed());
        $this->conflict_state = $this->conflict_detector->scan();
        $this->connection_state = $this->bridge_config->build_connection_state($current_domain);
        $this->baseline_snapshot = $this->baseline_capture->capture($this->license_state, $this->conflict_state);
        $this->baseline_capture->persist_snapshot($this->baseline_snapshot);

        $mode = $this->determine_mode($this->license_state, $this->conflict_state, $this->bridge_profile, $this->baseline_snapshot);
        $safe_state = $this->safe_mode->build_state($mode, $this->license_state, $this->conflict_state, $this->baseline_snapshot, $this->bridge_profile);
        $this->optimization_state = $this->optimization_gate->evaluate($mode, $this->license_state, $this->conflict_state, $this->baseline_snapshot, $this->bridge_profile);

        $this->runtime_context = array(
            'plugin_version' => HSO_PLUGIN_VERSION,
            'current_domain' => $current_domain,
            'current_home_url' => isset($this->baseline_snapshot['current_home_url']) ? (string) $this->baseline_snapshot['current_home_url'] : '',
            'mode' => $mode,
            'default_mode' => (string) ($this->bridge_profile['default_mode'] ?? 'safe_mode'),
            'fallback_mode' => (string) ($this->bridge_profile['fallback_mode'] ?? 'observe_only'),
            'bound_domain' => isset($this->license_state['bound_domain']) ? (string) $this->license_state['bound_domain'] : '',
            'release_channel' => isset($this->license_state['release_channel']) ? (string) $this->license_state['release_channel'] : 'pilot',
            'allowed_scopes' => isset($this->license_state['allowed_scopes']) ? (array) $this->license_state['allowed_scopes'] : array(),
            'required_features' => isset($this->bridge_profile['required_features']) ? (array) $this->bridge_profile['required_features'] : array(),
            'source_mapping_confirmed' => !empty($this->bridge_profile['source_mapping_confirmed']),
            'scope_confirmed' => !empty($this->bridge_profile['scope_confirmed']),
            'target_meta_description' => '',
            'suite_connection_readiness' => isset($this->connection_state['readiness']) ? (string) $this->connection_state['readiness'] : 'packaged_preview_ready',
            'url_normalization_clean' => !empty($this->baseline_snapshot['url_normalization_clean']),
            'staging_only' => !empty($this->bridge_profile['staging_only']),
            'safe_state' => $safe_state,
            'optimization_state' => $this->optimization_state,
        );

        $validation_snapshot = $this->validation_status->build_snapshot(
            $mode,
            $this->license_state,
            $this->conflict_state,
            $this->baseline_snapshot,
            array_merge($this->optimization_state, array('source_mapping_confirmed' => !empty($this->bridge_profile['source_mapping_confirmed']))),
            $this->connection_state
        );
        $this->validation_status->set_snapshot($validation_snapshot);

        $admin_screen = new HSO_Admin_Screen(
            $this->runtime_context,
            $this->bridge_profile,
            $this->license_state,
            $this->connection_state,
            $this->conflict_state,
            $this->baseline_snapshot,
            $this->optimization_state,
            $validation_snapshot
        );
        $admin_screen->register();

        $meta_description_module = new HSO_Meta_Description_Module(
            $this->runtime_context,
            $this->conflict_state,
            $this->rollback_registry,
            $this->validation_status
        );
        $meta_description_module->register();
    }

    private function determine_mode(
        array $license_state,
        array $conflict_state,
        array $bridge_profile,
        array $baseline_snapshot
    ): string
    {
        $default_mode = isset($bridge_profile['default_mode']) ? (string) $bridge_profile['default_mode'] : 'safe_mode';

        if (!empty($conflict_state['has_blocking_conflict'])) {
            return 'safe_mode';
        }

        if (empty($license_state['bound_domain']) || empty($license_state['domain_match'])) {
            return 'observe_only';
        }

        if (!empty($baseline_snapshot) && empty($baseline_snapshot['url_normalization_clean'])) {
            return 'safe_mode';
        }

        $status = isset($license_state['status']) ? (string) $license_state['status'] : 'approval_required';
        if (in_array($status, array('inactive', 'revoked'), true)) {
            return 'observe_only';
        }

        if ($status !== 'active_scoped') {
            if (in_array($default_mode, array('safe_mode', 'observe_only', 'approval_required'), true)) {
                return $default_mode;
            }
            return 'approval_required';
        }

        if (!empty($conflict_state['source_mapping_unclear'])) {
            return 'approval_required';
        }

        if (empty($bridge_profile['source_mapping_confirmed']) || empty($bridge_profile['scope_confirmed'])) {
            return 'approval_required';
        }

        return 'active_scoped';
    }

    private function detect_current_domain(): string
    {
        if (function_exists('home_url')) {
            $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
            if (is_string($host)) {
                return strtolower($host);
            }
        }

        return '';
    }
}
