<?php

if (!defined('ABSPATH')) {
    exit;
}

class HSO_Safe_Mode
{
    public function build_state(
        string $mode,
        array $license_state,
        array $conflict_state,
        array $baseline_snapshot = array(),
        array $bridge_profile = array()
    ): array
    {
        $reasons = array();

        if ($mode === 'safe_mode') {
            $reasons[] = 'blocking conflict or malformed local state';
        }
        if (empty($license_state['domain_match'])) {
            $reasons[] = 'bound domain is missing or mismatched';
        }
        if (!empty($conflict_state['source_mapping_unclear'])) {
            $reasons[] = 'source mapping is not confirmed';
        }
        if (!empty($baseline_snapshot) && empty($baseline_snapshot['url_normalization_clean'])) {
            $reasons[] = 'url normalization is not yet clean';
        }
        if (!empty($bridge_profile['current_blockers'])) {
            $reasons = array_merge($reasons, array_map('strval', (array) $bridge_profile['current_blockers']));
        }

        return array(
            'mode' => $mode,
            'safe_mode_required' => $mode === 'safe_mode',
            'observe_only_required' => $mode === 'observe_only',
            'approval_required' => $mode === 'approval_required',
            'reasons' => array_values(array_unique($reasons)),
        );
    }
}
