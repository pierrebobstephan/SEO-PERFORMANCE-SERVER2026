<?php

if (!defined('ABSPATH')) {
    exit;
}

class HSO_Validation_Status
{
    private array $snapshot = array();

    public function set_snapshot(array $snapshot): void
    {
        $this->snapshot = $snapshot;
    }

    public function build_snapshot(
        string $mode,
        array $license_state,
        array $conflict_state,
        array $baseline_snapshot = array(),
        array $optimization_state = array(),
        array $connection_state = array()
    ): array
    {
        return array(
            'mode' => $mode,
            'license_status' => isset($license_state['status']) ? (string) $license_state['status'] : 'approval_required',
            'domain_match' => !empty($license_state['domain_match']),
            'primary_signals' => array(
                'homepage_meta_description_single' => false,
                'source_mapping_confirmed' => !empty($optimization_state['source_mapping_confirmed']),
                'url_normalization_clean' => !empty($baseline_snapshot['url_normalization_clean']),
            ),
            'neighbor_signals' => array(
                'title_stable' => true,
                'canonical_stable' => true,
                'robots_stable' => true,
                'rank_math_active' => !empty($conflict_state['rank_math_active']),
            ),
            'suite_connection' => array(
                'connection_mode' => isset($connection_state['connection_mode']) ? (string) $connection_state['connection_mode'] : 'packaged_preview_only',
                'readiness' => isset($connection_state['readiness']) ? (string) $connection_state['readiness'] : 'source not yet confirmed',
            ),
            'baseline_status' => array(
                'captured' => !empty($baseline_snapshot['captured']),
                'url_normalization_clean' => !empty($baseline_snapshot['url_normalization_clean']),
                'residuals' => isset($baseline_snapshot['url_normalization_residuals']) ? (array) $baseline_snapshot['url_normalization_residuals'] : array(),
            ),
            'optimization_eligibility' => isset($optimization_state['eligibility']) ? (string) $optimization_state['eligibility'] : 'recommend_only',
            'rollback_required' => $mode === 'safe_mode',
        );
    }

    public function get_snapshot(): array
    {
        return $this->snapshot;
    }
}
